@extends('shared.base')

@section('content')
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3>System to search for GitHub users</h3>
        </div>
        <div class="panel-body"<h3>Here you can search for GitHub users and see your repositories</h3>
        </div>
    </div>
@endsection
@section('footer')
@endsection
