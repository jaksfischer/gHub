@section('content')
    <div class="row">
        <div class="col-md-8">
            <h1>OOPS, 404 | NOT FOUND</h1>
        </div>
    </div>
@endsection
