<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3>System to search for GitHub users</h3>
        </div>
        <div class="panel-body"<h3>Here you can search for GitHub users and see your repositories</h3>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ghubTeste\resources\views/public.blade.php ENDPATH**/ ?>