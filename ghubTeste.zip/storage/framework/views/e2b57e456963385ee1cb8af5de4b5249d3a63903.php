<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <h1>OOPS, 404 | NOT FOUND</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\ghubTeste\resources\views/404.blade.php ENDPATH**/ ?>