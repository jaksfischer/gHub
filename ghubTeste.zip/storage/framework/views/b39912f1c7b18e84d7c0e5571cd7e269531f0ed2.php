<?php $__env->startSection('content'); ?>
    <h3>Página privada</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ghubTeste\resources\views/index.blade.php ENDPATH**/ ?>
